package com.zhm.lib_common.uitls

import com.zhm.lib_opensource.lib_retrofit.capsulation.ObjectLoader

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/3  16:54
 *用途
 ************************************
 */
object RetrofitUtil:ObjectLoader() {

}