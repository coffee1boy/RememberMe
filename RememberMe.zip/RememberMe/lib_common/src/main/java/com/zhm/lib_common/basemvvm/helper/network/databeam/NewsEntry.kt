package com.zhm.lib_common.basemvvm.helper.network.databeam

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/3  19:21
 *用途
 ************************************
 */
class NewsEntry {
    var _id: String? = null
    var createdAt: String? = null
    var desc: String? = null
    var publishedAt: String? = null
    var source: String? = null
    var type: String? = null
    var url: String? = null
    var used: Boolean = false
    var who: String? = null
}