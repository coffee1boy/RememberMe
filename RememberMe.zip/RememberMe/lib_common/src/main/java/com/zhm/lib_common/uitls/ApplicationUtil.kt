package com.zhm.lib_common.uitls

import android.app.Application

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/3  16:10
 *用途
 ************************************
 */
object ApplicationUtil {
    var mApplication:Application?=null
}