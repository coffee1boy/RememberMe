package com.zhm.lib_common.core

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/3  15:52
 *用途
 * 保存ARouter 路径
 ************************************
 */
object NavigationConstants {
    private const val NEWS="/news"
    const val LIVEDATAACTIVITY="$NEWS/LiveDataActivity"
    const val LIVEDATABACTIVITY="$NEWS/LiveDataBActivity"
    const val  NEWSONEACTIVITY="$NEWS/NewsOneActivity"

}