package com.zhm.lib_common.basemvvm.helper.network.databeam

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/3  19:19
 *用途
 ************************************
 */
data class NewsResp(val error: Boolean, val results: List<NewsEntry>)