package com.zhm.lib_common.core

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/3  17:03
 *用途
 ************************************
 */
object RetrofitConstants {
    const val SUSPEND_URL="http://gank.io/api/data/福利/50/1/"//baseUrl
    const val SUSPEND_NEWSREQUEST_URL="http://gank.io/api/data/福利/50/1"//request interface Url
}