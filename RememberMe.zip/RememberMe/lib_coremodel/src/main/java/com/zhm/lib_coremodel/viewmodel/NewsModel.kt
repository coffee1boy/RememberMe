package com.zhm.lib_coremodel.viewmodel

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/4  11:06
 *用途
 ************************************
 */
class NewsModel:ViewModel(){
//    lateinit var userId:String
//    lateinit var user :MutableLiveData<String>
//    fun getContent(): MutableLiveData<String> {
//        if (user==null){
//            user= MutableLiveData()
//        }
//        return user
//    }
//    fun setContent(content:MutableLiveData<String>): Unit {
//        user=content
//    }
//    fun getContentData(): Unit {
//        //这里可以加一层Repository从网络/缓存加载数据
//        //执行完毕后调用 setValue/postValue方法,最终会回调Activity中的onChange方法
//
//        user.value = "我是获取到的数据"
//        //子线程调用  content.postValue(""我是获取到的数据")
//    }
}