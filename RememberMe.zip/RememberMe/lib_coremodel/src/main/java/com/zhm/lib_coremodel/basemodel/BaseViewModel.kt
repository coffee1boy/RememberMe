package com.zhm.lib_coremodel.basemodel

import android.arch.lifecycle.LifecycleObserver
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

/**
 ************************************
 *@Author revolve
 *创建时间：2019/9/4  17:40
 *用途
 ************************************
 */
open class BaseViewModel:ViewModel() ,LifecycleObserver{
//    val liveData:MutableLiveData<List<String>> = MutableLiveData()

}