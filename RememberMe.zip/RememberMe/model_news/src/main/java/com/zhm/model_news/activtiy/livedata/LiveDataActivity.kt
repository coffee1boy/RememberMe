package com.zhm.model_news.activtiy.livedata

import android.arch.lifecycle.GenericLifecycleObserver
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.alibaba.android.arouter.facade.annotation.Route
import com.zhm.lib_common.core.NavigationConstants
import com.zhm.model_news.R
/**
 * Activity继承AppCompatActivity即FragmentActivity的情况下
 * 怎么使用lifecycle
 * */
@Route(path = "${NavigationConstants.LIVEDATAACTIVITY}")
class LiveDataActivity : AppCompatActivity() {
    private val TAG=javaClass.simpleName
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_data)
//        lifecycle.addObserver(GenericLifecycleObserver{source, event ->
//            Log.d(TAG,"OnStateChange:event="+event)
//        })
        MediaCompement(this)
    }
}
